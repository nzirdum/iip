<?php

session_start();
include_once 'baza.php';
include_once 'navigacija.php';
$podatci = array();

if (isset($_GET['id'])) {
    $upit = "SELECT * FROM korisnik WHERE id={$_GET['id']}";
    $rezultat = izvrsiUpit($upit);
    $podatci = mysqli_fetch_assoc($rezultat);
}

function spremiProfesora() {
    $dozvoljene_domene = ['unipu.hr'];

    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        $ime = $_POST['ime'];
        $prezime = $_POST['prezime'];
        $korisnicko_ime = $_POST['korisnicko_ime'];
        $lozinka = $_POST['lozinka'];
        $email = $_POST['email'];
        $datum_rodenja = date("Y-m-d", strtotime($_POST['datum_rodenja']));
        $mjesto_rodenja = $_POST['mjesto_rodenja'];
        $zemlja_rodenja = $_POST['zemlja_rodenja'];
        $id = $_POST['id'];

        $upit = "SELECT * FROM korisnik WHERE korisnicko_ime='{$korisnicko_ime}' AND id<>{$id}";
        $rezultat = izvrsiUpit($upit);
        if (mysqli_num_rows($rezultat) == 0 ) {
            $upit = "SELECT * FROM korisnik WHERE email='{$email}' AND id<>{$id}";
            $rezultat = izvrsiUpit($upit);
            if (mysqli_num_rows($rezultat) == 0) {
                $email_dijelovi = explode('@', $email);
                $email_domena = array_pop($email_dijelovi);

                if (!in_array($email_domena, $dozvoljene_domene)) {
                    echo "<p class='info'>Unijeli ste email koji se nema odgovarajuću domenu (unipu.hr). Molimo pokušajte ponovno!</p>";
                } else {
                    if ($id == 0) {
                        $slika = "korisnici/".$korisnicko_ime.".jpg";
                        move_uploaded_file($_FILES['slika']['tmp_name'], $slika);

                        $upit = "INSERT INTO korisnik(tip_korisnika_id, vrsta_studija_id, korisnicko_ime, lozinka, ime, prezime, email, slika, datum_rodenja, mjesto_rodenja, zemlja_rodenja) VALUES (2, 2, '{$korisnicko_ime}', '{$lozinka}', '{$ime}', '{$prezime}', '{$email}', '{$slika}', '{$datum_rodenja}', '{$mjesto_rodenja}', '{$zemlja_rodenja}')";
                        $rezultat = izvrsiUpit($upit);
                        header("Location: administrator_popis_profesora.php");
                    } else {
                        $upit = "UPDATE korisnik SET korisnicko_ime='{$korisnicko_ime}', lozinka='{$lozinka}', ime='{$ime}', prezime='{$prezime}', email='{$email}', datum_rodenja='{$datum_rodenja}', mjesto_rodenja='{$mjesto_rodenja}', zemlja_rodenja='{$zemlja_rodenja}' WHERE id={$id}";
                        $rezultat = izvrsiUpit($upit);
                        header("Location: administrator_popis_profesora.php");
                    }
                }
            } else {
                echo "<p class='info'>Unijeli ste email koji se već koristi. Molimo pokušajte ponovno!</p>";
            }
        } else {
            echo "<p class='info'>Unijeli ste korisničko ime koje se već koristi. Molimo pokušajte ponovno!</p>";
        }

        $_GET['id'] = $id;
        global $podatci;
        $podatci['ime'] = $ime;
        $podatci['prezime'] = $prezime;
        $podatci['korisnicko_ime'] = $korisnicko_ime;
        $podatci['lozinka'] = $lozinka;
        $podatci['email'] = $email;
        $podatci['datum_rodenja'] = $datum_rodenja;
        $podatci['mjesto_rodenja'] = $mjesto_rodenja;
        $podatci['zemlja_rodenja'] = $zemlja_rodenja;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Uređivanje profesora</title>
    <link href="css/glavniDizajn.css" rel="stylesheet" type="text/css">
    <link rel="icon" type="image/png" href="slika.png">
</head>
<body>
<header>
    <h1>Uređivanje profesora</h1>
</header>
<nav>
    <ul>
        <?php prikaziNavigaciju(); ?>
    </ul>
</nav>
<section>
    <?php spremiProfesora(); ?>
    <form method="post" action="administrator_uredivanje_profesora.php" enctype="multipart/form-data">
        <label>Ime</label>
        <input type="text" name="ime" required value="<?php if (isset($_GET['id'])) echo $podatci['ime']; ?>"><br/>
        <label>Prezime</label>
        <input type="text" name="prezime" required value="<?php if (isset($_GET['id'])) echo $podatci['prezime']; ?>"><br/>
        <label>Korisničko ime</label>
        <input type="text" name="korisnicko_ime" required value="<?php if (isset($_GET['id'])) echo $podatci['korisnicko_ime']; ?>"><br/>
        <label>Lozinka</label>
        <input type="text" name="lozinka" required value="<?php if (isset($_GET['id'])) echo $podatci['lozinka']; ?>"><br/>
        <label>Email</label>
        <input type="email" name="email" required value="<?php if (isset($_GET['id'])) echo $podatci['email']; ?>"><br/>
        <?php if (!isset($_GET['id']) || $_GET['id'] == 0): ?>
        <label>Slika</label>
        <input type="file" name="slika" required><br/>
        <?php endif; ?>
        <label>Datum rođenja</label>
        <input type="date" name="datum_rodenja" required value="<?php if (isset($_GET['id'])) echo $podatci['datum_rodenja']; ?>"><br/>
        <label>Mjesto rođenja</label>
        <input type="text" name="mjesto_rodenja" required value="<?php if (isset($_GET['id'])) echo $podatci['mjesto_rodenja']; ?>"><br/>
        <label>Zemlja rođenja</label>
        <input type="text" name="zemlja_rodenja" required value="<?php if (isset($_GET['id'])) echo $podatci['zemlja_rodenja']; ?>"><br/>

        <input type="hidden" name="id" value="<?php if (isset($_GET['id'])) echo $_GET['id']; else echo "0";?>">
        <input type="submit" value="Spremi podatke o profesoru">
    </form>
</section>
</body>
</html>
