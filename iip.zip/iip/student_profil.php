<?php

session_start();
include_once 'baza.php';
include_once 'navigacija.php';

if (isset($_GET['id'])){
    $upit = "UPDATE rezervacija SET status_rezervacije_id=2 WHERE id={$_GET['id']}";
    $rezultat = izvrsiUpit($upit);
}

function prikaziMojProfil() {
    $upit = "SELECT * FROM rezervacija WHERE student_id={$_SESSION['korisnik_id']} ORDER BY id DESC";
    $rezultat = izvrsiUpit($upit);
    
    if (mysqli_num_rows($rezultat) == 0) {
        echo "<tr><td colspan='5'>Nemate niti jednu rezervaciju do sada</td></tr>";
    } else {
        foreach ($rezultat as $rezervacija) {
            $upit = "SELECT * FROM tema WHERE id={$rezervacija['tema_id']}";
            $rezultat1 = izvrsiUpit($upit);
            $tema = mysqli_fetch_assoc($rezultat1);

            $upit = "SELECT * FROM korisnik WHERE id={$tema['profesor_id']}";
            $rezultat1 = izvrsiUpit($upit);
            $profesor = mysqli_fetch_assoc($rezultat1);

            $upit = "SELECT * FROM status_rezervacije WHERE id={$rezervacija['status_rezervacije_id']}";
            $rezultat1 = izvrsiUpit($upit);
            $status = mysqli_fetch_assoc($rezultat1);

            echo "<tr>";
            echo "<td>{$tema['naziv']}</td>";
            echo "<td>{$tema['opis']}</td>";
            echo "<td>{$profesor['prezime']} {$profesor['ime']}</td>";
            echo "<td>{$status['naziv']}</td>";

            if ($rezervacija['status_rezervacije_id'] == 1) {
                echo "<td><ul>";
                echo "<li><b>Datum kreiranja: </b>".date("d.m.Y", strtotime($rezervacija['datum_kreiranja']))."</li>";
                echo "<li><b>Datum prihvacanja rezervacije: </b>".date("d.m.Y", strtotime($rezervacija['datum_vrijedi_od']))."</li>";
                echo "<li><b>Rezervacija vrijedi do: </b>".date("d.m.Y", strtotime($rezervacija['datum_vrijedi_do']))."</li>";
                echo "</ul></td>";
            } else {
                echo "<td><ul>";
                echo "<li><b>Datum kreiranja: </b>".date("d.m.Y", strtotime($rezervacija['datum_kreiranja']))."</li>";
                if ($rezervacija['status_rezervacije_id'] == 3) {
                    echo "<li><a href='student_profil.php?id={$rezervacija['id']}'><button>Poništi rezervaciju</button></a></li>";
                }
                echo "</ul></td>";
            }

            echo "</tr>";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Moj profil</title>
    <link href="css/glavniDizajn.css" rel="stylesheet" type="text/css">
    <link rel="icon" type="image/png" href="slika.png">
</head>
<body>
<header>
    <h1>Moj profil</h1>
</header>
<nav>
    <ul>
        <?php prikaziNavigaciju(); ?>
    </ul>
</nav>
<section>
    <table>
        <thead>
            <th>Tema</th><th>Opis teme</th><th>Mentor</th><th>Status rezervacije</th><th>O rezervaciji</th>
        </thead>
        <tbody>
            <?php prikaziMojProfil(); ?>
        </tbody>
    </table>
</section>
</body>
</html>
