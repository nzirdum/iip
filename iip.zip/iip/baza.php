<?php

function kreirajKonekciju() {
    $konekcija = mysqli_connect("localhost", "root", "", "radovi");
    mysqli_set_charset($konekcija, "utf8");

    return $konekcija;
}

function izvrsiUpit($upit) {
    $konekcija = kreirajKonekciju();
    $rezultatUpita = mysqli_query($konekcija, $upit);
    zatvoriKonekciju($konekcija);

    return $rezultatUpita;
}

function zatvoriKonekciju($konekcija) {
    mysqli_close($konekcija);
}

?>



