<?php

session_start();
include_once 'baza.php';
include_once 'navigacija.php';

if (isset($_GET['odbij'])) {
    $upit = "UPDATE rezervacija SET status_rezervacije_id=2 WHERE id={$_GET['odbij']}";
    $rezultat = izvrsiUpit($upit);
} else if (isset($_GET['prihvati'])) {
    $upit = "SELECT * FROM rezervacija WHERE id={$_GET['prihvati']}";
    $rezultat = izvrsiUpit($upit);
    $rezervacija = mysqli_fetch_assoc($rezultat);

    $upit = "UPDATE rezervacija SET status_rezervacije_id=2 WHERE tema_id={$rezervacija['tema_id']}";
    $rezultat = izvrsiUpit($upit);

    $datum_vrijedi_od = date("Y-m-d");
    $datum_vrijedi_do = date("Y-m-d", strtotime($datum_vrijedi_od) + 60*60*24*365*2);
    $upit = "UPDATE rezervacija SET datum_vrijedi_od='{$datum_vrijedi_od}', datum_vrijedi_do='{$datum_vrijedi_do}', status_rezervacije_id=1 WHERE id={$rezervacija['id']}";
    $rezultat = izvrsiUpit($upit);

    $upit = "UPDATE tema SET status_teme_id=2 WHERE id={$rezervacija['tema_id']}";
    $rezultat = izvrsiUpit($upit);
}

function prikaziPopisTema() {
    $upit = "SELECT * FROM tema WHERE profesor_id={$_SESSION['korisnik_id']} ORDER BY vrsta_studija_id ASC, datum_kreiranja DESC";
    $rezultat = izvrsiUpit($upit);

    if (mysqli_num_rows($rezultat) == 0) {
        echo "<tr><td colspan='6'>Trenutno nemate niti jednu kreiranu temu</td></tr>";
    } else {
        foreach ($rezultat as $tema) {
            $upit = "SELECT * FROM vrsta_studija WHERE id={$tema['vrsta_studija_id']}";
            $rezultat1 = izvrsiUpit($upit);
            $studij = mysqli_fetch_assoc($rezultat1);

            $upit = "SELECT * FROM status_teme WHERE id={$tema['status_teme_id']}";
            $rezultat1 = izvrsiUpit($upit);
            $status = mysqli_fetch_assoc($rezultat1);

            echo "<tr>";
            echo "<td>{$studij['naziv']}</td>";
            echo "<td>{$tema['naziv']}</td>";
            echo "<td>{$tema['opis']}</td>";
            echo "<td>".date("d.m.Y", strtotime($tema['datum_kreiranja']))."</td>";
            echo "<td>{$status['naziv']}</td>";

            if ($tema['status_teme_id'] == 1) {
                $upit = "SELECT * FROM rezervacija WHERE tema_id={$tema['id']} AND status_rezervacije_id=3";
                $rezultat1 = izvrsiUpit($upit);
                if (mysqli_num_rows($rezultat1) == 0) {
                    echo "<td>Nema rezervacija</td>";
                } else {
                    echo "<td><ul>";
                    foreach ($rezultat1 as $rezervacija) {
                        $upit = "SELECT * FROM korisnik WHERE id={$rezervacija['student_id']}";
                        $rezultat2 = izvrsiUpit($upit);
                        $student = mysqli_fetch_assoc($rezultat2);

                        echo "<li><b>{$student['prezime']} {$student['ime']}, ".date("d.m.Y", strtotime($rezervacija['datum_kreiranja']))."</b>";
                        echo "<a href='profesor_popis_tema.php?prihvati={$rezervacija['id']}'><button>Prihvati</button></a>";
                        echo "<a href='profesor_popis_tema.php?odbij={$rezervacija['id']}'><button>Odbij</button></a></li>";
                    }
                    echo "</ul></td>";
                }
            } else {
                $upit = "SELECT * FROM rezervacija WHERE tema_id={$tema['id']} AND status_rezervacije_id=1";
                $rezultat1 = izvrsiUpit($upit);
                $rezervacija = mysqli_fetch_assoc($rezultat1);

                $upit = "SELECT * FROM korisnik WHERE id={$rezervacija['student_id']}";
                $rezultat1 = izvrsiUpit($upit);
                $student = mysqli_fetch_assoc($rezultat1);

                echo "<td><ul>";
                echo "<li><b>Student: </b>{$student['prezime']} {$student['ime']}</li>";
                echo "<li><b>Vrijedi od: </b>".date("d.m.Y", strtotime($rezervacija['datum_vrijedi_od']))."</li>";
                echo "<li><b>Vrijedi do: </b>".date("d.m.Y", strtotime($rezervacija['datum_vrijedi_do']))."</li>";
                echo "</ul></td>";
            }

            echo "<td><a href='profesor_uredivanje_tema.php?id={$tema['id']}'><button>Uredi</button></a></td>";
            echo "</tr>";
        }
    }


}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Popis tema</title>
    <link href="css/glavniDizajn.css" rel="stylesheet" type="text/css">
    <link rel="icon" type="image/png" href="slika.png">
</head>
<body>
<header>
    <h1>Popis tema</h1>
</header>
<nav>
    <ul>
        <?php prikaziNavigaciju(); ?>
    </ul>
</nav>
<section>
    <table>
        <thead>
            <th>Studij</th><th>Naziv teme</th><th>Opis teme</th><th>Datum kreiranja</th><th>Status teme</th><th>Rezervacija</th><th>Opcije</th>
        </thead>
        <tbody>
            <?php prikaziPopisTema(); ?>
        </tbody>
    </table>
</section>
</body>
</html>
