<?php

session_start();
include_once 'baza.php';
include_once 'navigacija.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Početna stranica</title>
    <link href="css/glavniDizajn.css" rel="stylesheet" type="text/css">
    <link rel="icon" type="image/png" href="slika.png">
</head>
<body>
<header>
    <h1>Fakultet informatike u Puli <img src="logo.png" alt="logo_fipu_unipu" style="float:right"/></h1>
</header>
<nav>
    <ul>
        <?php prikaziNavigaciju(); ?>
    </ul>
</nav>
<section>
    <p class="index">Dobrodošli na aplikaciju za rezervaciju tema
        završnih i diplomskih radova <img src="slika.png" alt="radovi" style="float:right"/></p>
</section>
</body>
</html>


