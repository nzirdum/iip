<?php

session_start();
include_once 'baza.php';
include_once 'navigacija.php';

function prijavi() {
    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        $korisnicko_ime = $_POST['korisnicko_ime'];
        $lozinka = $_POST['lozinka'];

        $upit = "SELECT * FROM korisnik WHERE korisnicko_ime='{$korisnicko_ime}' AND lozinka='{$lozinka}'";
        $rezultat = izvrsiUpit($upit);

        if (mysqli_num_rows($rezultat) == 1) {
            $korisnik = mysqli_fetch_assoc($rezultat);
            $_SESSION['tip_korisnika_id'] = $korisnik['tip_korisnika_id'];
            $_SESSION['korisnik_id'] = $korisnik['id'];
            $_SESSION['studij_id'] = $korisnik['vrsta_studija_id'];

            switch ($korisnik['tip_korisnika_id']) {
                case 1:
                    header("Location: administrator_popis_profesora.php");
                    break;
                case 2:
                    header("Location: profesor_popis_tema.php");
                    break;
                case 3:
                    header("Location: student_profil.php");
                    break;
                default:
                    header("Location: odjava.php");
            }
        } else {
          echo "<p class='info'>Unijeli ste pogrešne korisničke podatke za prijavu na sustav. Molimo pokušajte ponovno!</p>";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Prijava</title>
    <link href="css/glavniDizajn.css" rel="stylesheet" type="text/css">
    <link rel="icon" type="image/png" href="slika.png">
</head>
<body>
<header>
    <h1>Prijava</h1>
</header>
<nav>
    <ul>
        <?php prikaziNavigaciju(); ?>
    </ul>
</nav>
<section>
    <?php prijavi(); ?>
    <form method="post" action="prijava.php">
        <label>Korisničko ime</label>
        <input type="text" name="korisnicko_ime" required><br/>
        <label>Lozinka</label>
        <input type="password" name="lozinka" required><br/>

        <input type="submit" value="Prijavi me">
    </form>
</section>
</body>
</html>