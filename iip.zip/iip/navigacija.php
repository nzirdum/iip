<?php

function prikaziNavigaciju() {
    if (!isset($_SESSION['tip_korisnika_id'])) {
        prikaziNavigacijuAnonimniKorisnik();
    } else {
        switch ($_SESSION['tip_korisnika_id']){
            case 1:
                prikaziNavigacijuAdministrator();
                break;
            case 2:
                prikaziNavigacijuProfesor();
                break;
            case 3:
                prikaziNavigacijuStudent();
                break;
        }
    }
}

function prikaziNavigacijuAdministrator() {
    echo "<li><a href='index.php'>Početna stranica</a></li>";
    echo "<li><a href='administrator_popis_studenata.php'>Popis studenata</a></li>";
    echo "<li><a href='administrator_popis_profesora.php'>Popis profesora</a></li>";
    echo "<li><a href='administrator_uredivanje_studenta.php'>Dodavanje studenta</a></li>";
    echo "<li><a href='administrator_uredivanje_profesora.php'>Dodavanje profesora</a></li>";
    echo "<li><a href='odjava.php'>Odjava</a></li>";
}

function prikaziNavigacijuProfesor() {
    echo "<li><a href='index.php'>Početna stranica</a></li>";
    echo "<li><a href='profesor_popis_tema.php'>Popis tema</a></li>";
    echo "<li><a href='profesor_uredivanje_tema.php'>Dodavanje tema</a></li>";
    echo "<li><a href='odjava.php'>Odjava</a></li>";
}

function prikaziNavigacijuStudent() {
    echo "<li><a href='index.php'>Početna stranica</a></li>";
    echo "<li><a href='student_profil.php'>Moj profil</a></li>";
    echo "<li><a href='student_popis_tema.php'>Popis tema</a></li>";
    echo "<li><a href='odjava.php'>Odjava</a></li>";
}

function prikaziNavigacijuAnonimniKorisnik() {
    echo "<li><a href='index.php'>Početna stranica</a></li>";
    echo "<li><a href='prijava.php'>Prijava</a></li>";
}

?>