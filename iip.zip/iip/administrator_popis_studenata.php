<?php

session_start();
include_once 'baza.php';
include_once 'navigacija.php';

function prikaziPopisStudenata() {
    $upit = "SELECT * FROM korisnik WHERE tip_korisnika_id=3 ORDER BY vrsta_studija_id DESC, prezime ASC, ime ASC";
    $rezultat = izvrsiUpit($upit);

    foreach ($rezultat as $student) {
        $upit = "SELECT * FROM vrsta_studija WHERE id={$student['vrsta_studija_id']}";
        $rezultat1 = izvrsiUpit($upit);
        $studij = mysqli_fetch_assoc($rezultat1);

        echo "<tr>";
        echo "<td><img src='{$student['slika']}' width='100' height='125'></td>";
        echo "<td>{$studij['naziv']}</td>";
        echo "<td>{$student['prezime']}</td>";
        echo "<td>{$student['ime']}</td>";
        echo "<td>{$student['email']}</td>";
        echo "<td>{$student['jmbag']}</td>";
        echo "<td>{$student['korisnicko_ime']}</td>";
        echo "<td>{$student['lozinka']}</td>";
        echo "<td>".date("d.m.Y", strtotime($student['datum_rodenja']))."</td>";
        echo "<td>{$student['mjesto_rodenja']}</td>";
        echo "<td>{$student['zemlja_rodenja']}</td>";
        echo "<td><a href='administrator_uredivanje_studenta.php?id={$student['id']}'><button>Uredi</button></a></td>";
        echo "</tr>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Popis studenata</title>
    <link href="css/glavniDizajn.css" rel="stylesheet" type="text/css">
    <link rel="icon" type="image/png" href="slika.png">
</head>
<body>
<header>
    <h1>Popis studenta</h1>
</header>
<nav>
    <ul>
        <?php prikaziNavigaciju(); ?>
    </ul>
</nav>
<section>
    <table>
        <thead>
            <th>Slika</th><th>Studij</th><th>Prezime</th><th>Ime</th><th>Email</th><th>JMBAG</th><th>Korisničko ime</th><th>Lozinka</th><th>Datum rođenja</th><th>Mjesto rođenja</th><th>Zemlja rođenja</th><th>Opcije</th>
        </thead>
        <tbody>
            <?php prikaziPopisStudenata(); ?>
        </tbody>
    </table>
</section>
</body>
</html>
