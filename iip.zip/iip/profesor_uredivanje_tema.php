<?php

session_start();
include_once 'baza.php';
include_once 'navigacija.php';
$podatci = array();

if (isset($_GET['id'])) {
    $upit = "SELECT * FROM tema WHERE id={$_GET['id']}";
    $rezultat = izvrsiUpit($upit);
    $podatci = mysqli_fetch_assoc($rezultat);
}

function prikaziStudije() {
    if (isset($_GET['id'])) {
        global $podatci;
    }

    $upit = "SELECT * FROM vrsta_studija";
    $rezultat = izvrsiUpit($upit);

    foreach ($rezultat as $vrsta_studija) {
        if (isset($_GET['id']) && $vrsta_studija['id'] == $podatci['vrsta_studija_id']) {
            echo "<option value='{$vrsta_studija['id']}' selected>{$vrsta_studija['naziv']}</option>";
        } else {
            echo "<option value='{$vrsta_studija['id']}'>{$vrsta_studija['naziv']}</option>";
        }
    }
}

function spremiTemu() {
    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        $studij = $_POST['studij'];
        $naziv = $_POST['naziv'];
        $opis = $_POST['opis'];
        $id = $_POST['id'];

        $upit = "SELECT * FROM tema WHERE naziv='{$naziv}' AND id<>{$id}";
        $rezultat = izvrsiUpit($upit);
        if (mysqli_num_rows($rezultat) == 0 ) {
            if ($id == 0) {
                $datum_kreiranja = date("Y-m-d");

                $upit = "INSERT INTO tema(naziv, opis, datum_kreiranja, profesor_id, vrsta_studija_id, status_teme_id) VALUES ('{$naziv}', '{$opis}', '{$datum_kreiranja}', {$_SESSION['korisnik_id']}, {$studij}, 1)";
                $rezultat = izvrsiUpit($upit);
                header("Location: profesor_popis_tema.php");
            } else {
                $upit = "UPDATE tema SET naziv='{$naziv}', opis='{$opis}', vrsta_studija_id={$studij} WHERE id={$id}";
                $rezultat = izvrsiUpit($upit);
                header("Location: profesor_popis_tema.php");
            }
        } else {
            echo "<p class='info'>Unijeli ste naziv teme koja već postoji u sustavu. Molimo pokušajte ponovno!</p>";
        }

        $_GET['id'] = $id;
        global $podatci;
        $podatci['vrsta_studija_id'] = $studij;
        $podatci['naziv'] = $naziv;
        $podatci['opis'] = $opis;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Uređivanje teme</title>
    <link href="css/glavniDizajn.css" rel="stylesheet" type="text/css">
    <link rel="icon" type="image/png" href="slika.png">
</head>
<body>
<header>
    <h1>Uređivnje teme</h1>
</header>
<nav>
    <ul>
        <?php prikaziNavigaciju(); ?>
    </ul>
</nav>
<section>
    <?php spremiTemu(); ?>
    <form method="post" action="profesor_uredivanje_tema.php">
        <label>Studij</label>
        <select name="studij">
            <?php prikaziStudije(); ?>
        </select><br/>
        <label>Naziv teme</label>
        <input type="text" name="naziv" required value="<?php if (isset($_GET['id'])) echo $podatci['naziv']; ?>"><br/>
        <label>Opis teme</label>
        <textarea name="opis" required><?php if (isset($_GET['id'])) echo $podatci['opis']; ?></textarea><br/>

        <input type="hidden" name="id" value="<?php if (isset($_GET['id'])) echo $_GET['id']; else echo "0";?>">
        <input type="submit" value="Spremi podatke o temi">
    </form>
</section>
</body>
</html>
