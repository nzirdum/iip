-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 23, 2020 at 01:12 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `radovi`
--

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

CREATE TABLE `korisnik` (
  `id` int(11) NOT NULL,
  `tip_korisnika_id` int(11) NOT NULL,
  `vrsta_studija_id` int(11) NOT NULL,
  `korisnicko_ime` varchar(30) NOT NULL,
  `lozinka` varchar(30) NOT NULL,
  `ime` varchar(30) NOT NULL,
  `prezime` varchar(25) NOT NULL,
  `email` varchar(50) NOT NULL,
  `slika` varchar(200) NOT NULL,
  `jmbag` int(10) DEFAULT NULL,
  `datum_rodenja` date NOT NULL,
  `mjesto_rodenja` varchar(100) NOT NULL,
  `zemlja_rodenja` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`id`, `tip_korisnika_id`, `vrsta_studija_id`, `korisnicko_ime`, `lozinka`, `ime`, `prezime`, `email`, `slika`, `jmbag`, `datum_rodenja`, `mjesto_rodenja`, `zemlja_rodenja`) VALUES
(1, 1, 2, 'admin', 'admin', 'Administrator', 'Sustava', 'admin@unipu.hr', 'korisnici/admin.jpg', NULL, '1994-03-18', 'Zagreb', 'Republika Hrvatska'),
(2, 2, 2, 'fsuran', '123456', 'Fulvio', 'Šuran', 'fsuran@unipu.hr', 'korisnici/fsuran.jpg', NULL, '1968-08-11', 'Zagreb', 'Republika Hrvatska'),
(3, 2, 2, 'iblazevic', '123456', 'Iva', 'Blažević', 'iblazevic@unipu.hr', 'korisnici/iblazevic.jpg', NULL, '1975-08-27', 'Rijeka', 'Republika Hrvatska'),
(4, 2, 2, 'vjurdana', '123456', 'Vjekoslava', 'Jurdana', 'vjurdana@unipu.hr', 'korisnici/vjurdana.jpg', NULL, '1966-06-16', 'Ogulin', 'Republika Hrvatska'),
(5, 2, 2, 'sbertosa', '123456', 'Slaven', 'Bertoša', 'sbertosa@unipu.hr', 'korisnici/sbertosa.jpg', NULL, '1983-11-19', 'Pula', 'Republika Hrvatska'),
(6, 2, 2, 'ipogarcic', '123456', 'Ivan', 'Pogarčić', 'ipogarcic@unipu.hr', 'korisnici/ipogarcic.jpg', NULL, '1981-03-19', 'Split', 'Republika Hrvatska'),
(7, 2, 2, 'llazaric', '123456', 'Lorena', 'Lazarić', 'llazaric@unipu.hr', 'korisnici/llazaric.jpg', NULL, '1958-04-18', 'Pula', 'Republika Hrvatska'),
(8, 3, 2, 'alasic', '123456', 'Ante', 'Lasić', 'alasic@unipu.hr', 'korisnici/alasic.jpg', 16055001, '1996-08-03', 'Pula', 'Republika Hrvatska'),
(9, 3, 2, 'agulin', '123456', 'Antonija', 'Gulin', 'agulin@unipu.hr', 'korisnici/agulin.jpg', 16055002, '1995-10-16', 'Zabok', 'Republika Hrvatska'),
(10, 3, 2, 'dgudelj', '123456', 'Dino', 'Gudelj', 'dgudelj@unipu.hr', 'korisnici/dgudelj.jpg', 16055003, '1993-06-23', 'Karlovac', 'Republika Hrvatska'),
(11, 3, 2, 'dmiholic', '123456', 'Danijela', 'Miholić', 'dmiholic@unipu.hr', 'korisnici/dmiholic.jpg', 16055004, '1995-12-03', 'Pula', 'Republika Hrvatska'),
(12, 3, 2, 'zpozeglic', '123456', 'Zvonimir', 'Požeglić', 'zpozeglic@unipu.hr', 'korisnici/zpozeglic.jpg', 16055005, '1996-04-13', 'Rijeka', 'Republika Hrvatska'),
(13, 3, 2, 'mdurin', '123456', 'Matija', 'Đurin', 'mdurin@unipu.hr', 'korisnici/mdurin.jpg', 16055006, '1993-01-08', 'Pula', 'Republika Hrvatska'),
(14, 3, 1, 'itolic', '123456', 'Ivana', 'Tolić', 'itolic@unipu.hr', 'korisnici/itolic.jpg', 16055007, '1998-06-02', 'Poreč', 'Republika Hrvatska'),
(15, 3, 1, 'dlisov', '123456', 'Denis', 'Lisov', 'dlisov@unipu.hr', 'korisnici/dlisov.jpg', 16055008, '2000-08-26', 'Pula', 'Republika Hrvatska'),
(16, 3, 1, 'jkasa', '123456', 'Jana', 'Kasa', 'jkasa@unipu.hr', 'korisnici/jkasa.jpg', 16055009, '1999-12-15', 'Osijek', 'Republika Hrvatska'),
(17, 3, 1, 'dbilusic', '123456', 'Davor', 'Bilušić', 'dbilusic@unipu.hr', 'korisnici/dbilusic.jpg', 16055010, '1999-05-07', 'Ogulin', 'Republika Hrvatska'),
(18, 3, 1, 'egenda', '123456', 'Ena', 'Genda', 'egenda@unipu.hr', 'korisnici/egenda.jpg', 16055011, '1998-09-21', 'Zadar', 'Republika Hrvatska'),
(19, 3, 1, 'rselendic', '123456', 'Robert', 'Šelendić', 'rselendic@unipu.hr', 'korisnici/rselendic.jpg', 16055012, '2000-03-02', 'Dubrovnik', 'Republika Hrvatsk'),
(20, 3, 1, 'mvuglenovic', '123456', 'Marta', 'Vuglenović', 'mvuglenovic@unipu.hr', 'korisnici/mvuglenovic.jpg', 16055013, '1999-02-27', 'Split', 'Republika Hrvatska'),
(21, 3, 1, 'momelic', '123456', 'Marko', 'Omelić', 'momelic@unipu.hr', 'korisnici/momelic.jpg', 16055014, '1998-08-01', 'Pula ', 'Republika Hrvatska'),
(22, 3, 1, 'jcindric', '123456', 'Josip', 'Cindrić', 'jcindric@unipu.hr', 'korisnici/jcindric.jpg', 16055015, '1997-10-15', 'Pula', 'Republika Hrvatska'),
(23, 2, 2, 'ijurkovic', '123456', 'Ivan', 'Jurković', 'ijurkovic@unipu.hr', 'korisnici/ijurkovic.jpg', NULL, '1982-08-06', 'Pula', 'Republika Hrvatska'),
(24, 3, 2, 'mivkovic', '123456', 'Marina', 'Ivković', 'mivkovic@unipu.hr', 'korisnici/mivkovic', 16099386, '1996-08-12', 'Rijeka', 'Republika Hrvatska');

-- --------------------------------------------------------

--
-- Table structure for table `rezervacija`
--

CREATE TABLE `rezervacija` (
  `id` int(11) NOT NULL,
  `tema_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `datum_kreiranja` date NOT NULL,
  `datum_vrijedi_od` date DEFAULT NULL,
  `datum_vrijedi_do` date DEFAULT NULL,
  `status_rezervacije_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rezervacija`
--

INSERT INTO `rezervacija` (`id`, `tema_id`, `student_id`, `datum_kreiranja`, `datum_vrijedi_od`, `datum_vrijedi_do`, `status_rezervacije_id`) VALUES
(1, 11, 13, '2020-08-22', '2020-08-23', '2022-08-23', 1),
(2, 4, 10, '2020-08-23', NULL, NULL, 2),
(3, 21, 10, '2020-08-23', NULL, NULL, 3),
(4, 7, 16, '2020-08-23', NULL, NULL, 3);

-- --------------------------------------------------------

--
-- Table structure for table `status_rezervacije`
--

CREATE TABLE `status_rezervacije` (
  `id` int(11) NOT NULL,
  `naziv` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `status_rezervacije`
--

INSERT INTO `status_rezervacije` (`id`, `naziv`) VALUES
(1, 'Odobrena rezervacija'),
(2, 'Odbijena rezervacija'),
(3, 'Rezervacija na čekanju');

-- --------------------------------------------------------

--
-- Table structure for table `status_teme`
--

CREATE TABLE `status_teme` (
  `id` int(11) NOT NULL,
  `naziv` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `status_teme`
--

INSERT INTO `status_teme` (`id`, `naziv`) VALUES
(1, 'Slobodna tema'),
(2, 'Rezervirana tema'),
(3, 'Zakazana obrana'),
(4, 'Uspješno obranjena'),
(5, 'Neuspješno obranjena'),
(6, 'Istekla rezervacija');

-- --------------------------------------------------------

--
-- Table structure for table `tema`
--

CREATE TABLE `tema` (
  `id` int(11) NOT NULL,
  `naziv` varchar(200) NOT NULL,
  `opis` varchar(1000) NOT NULL,
  `datum_kreiranja` date NOT NULL,
  `profesor_id` int(11) NOT NULL,
  `vrsta_studija_id` int(11) NOT NULL,
  `status_teme_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tema`
--

INSERT INTO `tema` (`id`, `naziv`, `opis`, `datum_kreiranja`, `profesor_id`, `vrsta_studija_id`, `status_teme_id`) VALUES
(1, 'Uloga učitelja u školi 21. stoljeća', 'Opisati ulogu učitelja u školi 21. stoljeća. Razvoj škole od vremena antike do danas i usporedba. Metode učenja.', '2019-08-06', 2, 1, 1),
(2, 'Posljedice obiteljskog nasilja na budućnost djece', 'Opisati kakave posljedice obiteljsko nasilje ostavlja na budućnost djece. Promatrati s psihološkog i emocionalnog aspekta. Kakav odnos zlostavljana djeca imaju prema drugima i kakav utjecaj će to imati na njihovu obitelj jednog dana.', '2019-08-06', 2, 1, 1),
(3, 'Obrazovanje žena u povijesti', 'Opisati razvoj obrazovanja žena kroz povijest. Prava žena na obrazovanje.', '2019-08-06', 2, 2, 1),
(4, 'Društvo-mediji-odgoj/obrazovnje', 'Opisati ulogu društva i medija u obrzovanju i odgoju djece. Uloga roditelja i profesora u školama.', '2019-08-05', 2, 2, 1),
(5, 'Lokomotorni sustav djece rane i predškolske dobi', 'Opisati razvoj lokomotornog sustava kod djece rane i predškolske dobi', '2019-09-24', 3, 1, 1),
(6, 'Utjecaj tjelesnog vježbanja na razvojne karakteristike djece', 'Opisati utjecaj tjelesnog vježbanja na razvojne karakteristike djece.', '2019-09-24', 3, 1, 1),
(7, 'Crikvenička legenda o Maliku', 'Opisati crikveničku legendu o Maliku', '2019-10-09', 4, 1, 1),
(8, 'Umaška legenda o Rozamundi i pastiru', 'Opisati umašku legendu o Rozamundi i pastiru', '2019-10-09', 4, 1, 1),
(9, 'Petar Pan u radu s predškolskim djetetom', 'Opisati legendu o Petru Panu. Kakav utjecaj ima na rad s predškolskom djecom.', '2019-10-09', 4, 1, 1),
(10, 'Legenda o Riječkom zmaju', 'Opisati legendu o Riječkom zmaju', '2019-10-20', 4, 2, 1),
(11, 'Legenda o Atili na području Istre', 'Opisati legendu o Atili na području Istre', '2019-09-23', 4, 2, 2),
(12, 'Istarski srednjovjekovni kašteli', 'Što je kaštel? Opisati neke od kaštela. Misteriozni kašteli (5)', '2019-10-05', 5, 1, 1),
(13, 'Hrvatske granice kroz povijest', 'Opisati legendu o nastanaku Hrvatske. Vladari i granice kroz povijest.', '2019-08-10', 5, 1, 1),
(14, 'Spomenici grada Zagreba', 'Opisati najznačajnije spomenike i znamenitosti grada Zagreba. Povijest Zagreba', '2019-08-10', 5, 1, 1),
(15, 'Znamenite žene u hrvatskoj povijesti', 'Opisati znamenite žene u hrvatskoj povijesti', '2019-08-10', 5, 1, 1),
(16, 'Sinjska alka', 'Opisati nastanak alke. Sinjska alka. Povijest i pobjednici.', '2019-08-10', 5, 1, 1),
(17, 'Mitovi i legende', 'Opisati mitove i legende stare Grčke. Također dodati najpozantije za svijet (Džingis kan, Atila, Romul i Rem)', '2019-08-10', 5, 2, 1),
(18, 'Političke stranke u Hrvatskoj u XIX. stoljeću', 'Opisati nastanak i djelovanja političkih stranaka u Hrvatskoj u XIX. stoljeću', '2019-08-10', 5, 2, 1),
(19, 'Pučka medicina', 'Opisati pučku medicinu u Hrvatskoj', '2019-08-25', 5, 2, 1),
(20, 'Računalno razmišljanje kroz igru', 'Opisati kako se uspostavlja računlno razmišljanje kroz igru i igrice', '2019-08-17', 6, 2, 1),
(21, 'Društvene igri u službi odgoja/obrazovanja', 'Opisati na koji način društevene igre pomažu u odgoju djece. Kakav utjecaj imaju na njihovo razmišljanje', '2019-08-17', 6, 2, 1),
(22, 'Učenje drugog/stranog jezika kroz igru', 'Opisati utjecaj igara na učenje stranih jezika', '2019-07-22', 7, 1, 1),
(23, 'Učinkovitost ranog učenja u ovladavanju drugim/stranim jezikom', 'Opisati učinkovitost ranog učenja u ovladavanju drugim/stranim jezikom', '2019-07-22', 7, 1, 1),
(24, 'Učenje jezika i moderno društvo', 'Opisati utjecaj učenja jezika na status u modernom društvu', '2019-07-22', 7, 1, 1),
(25, 'Utjecaj, razvoj i poticanje zavičajnog identiteta kod djece u vrtiću i obitelji', 'Opisati utjecaj, razvoj i poticanje zavičajnog identiteta kod djece u vrtiću i obitelji', '2019-07-22', 7, 1, 1),
(26, 'Odgoj nekad i danas', 'Opisati odgoj nekad i danas. Usporedba s antikom i srednjim vijekom', '2020-08-22', 2, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tip_korisnika`
--

CREATE TABLE `tip_korisnika` (
  `id` int(11) NOT NULL,
  `naziv` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tip_korisnika`
--

INSERT INTO `tip_korisnika` (`id`, `naziv`) VALUES
(1, 'Administrator'),
(2, 'Profesor'),
(3, 'Student');

-- --------------------------------------------------------

--
-- Table structure for table `vrsta_studija`
--

CREATE TABLE `vrsta_studija` (
  `id` int(11) NOT NULL,
  `naziv` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vrsta_studija`
--

INSERT INTO `vrsta_studija` (`id`, `naziv`) VALUES
(1, 'Prediplomski studij'),
(2, 'Diplomski studij');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tip_korisnika_id` (`tip_korisnika_id`),
  ADD KEY `vrsta_studija_id` (`vrsta_studija_id`);

--
-- Indexes for table `rezervacija`
--
ALTER TABLE `rezervacija`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tema_id` (`tema_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `status_rezervacije_id` (`status_rezervacije_id`);

--
-- Indexes for table `status_rezervacije`
--
ALTER TABLE `status_rezervacije`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `status_teme`
--
ALTER TABLE `status_teme`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tema`
--
ALTER TABLE `tema`
  ADD PRIMARY KEY (`id`),
  ADD KEY `profesor_id` (`profesor_id`),
  ADD KEY `vrsta_studija_id` (`vrsta_studija_id`),
  ADD KEY `status_teme_id` (`status_teme_id`);

--
-- Indexes for table `tip_korisnika`
--
ALTER TABLE `tip_korisnika`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vrsta_studija`
--
ALTER TABLE `vrsta_studija`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `korisnik`
--
ALTER TABLE `korisnik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `rezervacija`
--
ALTER TABLE `rezervacija`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `status_rezervacije`
--
ALTER TABLE `status_rezervacije`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `status_teme`
--
ALTER TABLE `status_teme`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tema`
--
ALTER TABLE `tema`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `tip_korisnika`
--
ALTER TABLE `tip_korisnika`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `vrsta_studija`
--
ALTER TABLE `vrsta_studija`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD CONSTRAINT `korisnik_ibfk_1` FOREIGN KEY (`vrsta_studija_id`) REFERENCES `vrsta_studija` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `korisnik_ibfk_2` FOREIGN KEY (`tip_korisnika_id`) REFERENCES `tip_korisnika` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rezervacija`
--
ALTER TABLE `rezervacija`
  ADD CONSTRAINT `rezervacija_ibfk_1` FOREIGN KEY (`status_rezervacije_id`) REFERENCES `status_rezervacije` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `rezervacija_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `korisnik` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `rezervacija_ibfk_3` FOREIGN KEY (`tema_id`) REFERENCES `tema` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tema`
--
ALTER TABLE `tema`
  ADD CONSTRAINT `tema_ibfk_1` FOREIGN KEY (`status_teme_id`) REFERENCES `status_teme` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tema_ibfk_2` FOREIGN KEY (`vrsta_studija_id`) REFERENCES `vrsta_studija` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tema_ibfk_3` FOREIGN KEY (`profesor_id`) REFERENCES `korisnik` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
