<?php

session_start();
include_once 'baza.php';
include_once 'navigacija.php';

function prikaziPopisProfesora() {
    $upit = "SELECT * FROM korisnik WHERE tip_korisnika_id=2 ORDER BY prezime ASC, ime ASC";
    $rezultat = izvrsiUpit($upit);

    foreach ($rezultat as $profesor) {
        echo "<tr>";
        echo "<td><img src='{$profesor['slika']}' width='100' height='125'></td>";
        echo "<td>{$profesor['prezime']}</td>";
        echo "<td>{$profesor['ime']}</td>";
        echo "<td>{$profesor['email']}</td>";
        echo "<td>{$profesor['korisnicko_ime']}</td>";
        echo "<td>{$profesor['lozinka']}</td>";
        echo "<td>".date("d.m.Y", strtotime($profesor['datum_rodenja']))."</td>";
        echo "<td>{$profesor['mjesto_rodenja']}</td>";
        echo "<td>{$profesor['zemlja_rodenja']}</td>";
        echo "<td><a href='administrator_uredivanje_profesora.php?id={$profesor['id']}'><button>Uredi</button></a></td>";
        echo "</tr>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Popis profesora</title>
    <link href="css/glavniDizajn.css" rel="stylesheet" type="text/css">
    <link rel="icon" type="image/png" href="slika.png">
</head>
<body>
<header>
    <h1>Popis profesora</h1>
</header>
<nav>
    <ul>
        <?php prikaziNavigaciju(); ?>
    </ul>
</nav>
<section>
    <table>
        <thead>
            <th>Slika</th><th>Prezime</th><th>Ime</th><th>Email</th><th>Korisničko ime</th><th>Lozinka</th><th>Datum rođenja</th><th>Mjesto rođenja</th><th>Zemlja rođenja</th><th>Opcije</th>
        </thead>
        <tbody>
            <?php prikaziPopisProfesora(); ?>
        </tbody>
    </table>
</section>
</body>
</html>
