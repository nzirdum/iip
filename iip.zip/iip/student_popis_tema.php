<?php

session_start();
include_once 'baza.php';
include_once 'navigacija.php';

if (isset($_GET['id'])) {
    $datum_kreiranja = date("Y-m-d");
    $upit = "INSERT INTO rezervacija(tema_id, student_id, datum_kreiranja, status_rezervacije_id) VALUES ({$_GET['id']}, {$_SESSION['korisnik_id']}, '{$datum_kreiranja}', 3)";
    $rezultat = izvrsiUpit($upit);
}

function prikaziPopisTema() {
    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        switch ($_POST['sortiraj']) {
            case 1:
                $sortiranje = "naziv ASC, prezime ASC, ime ASC, vrsta_studija_id ASC";
                break;
            case 2:
                $sortiranje = "prezime ASC, ime ASC, naziv ASC, vrsta_studija_id ASC";
                break;
            case 3:
                $sortiranje = "vrsta_studija_id ASC, naziv ASC, prezime ASC, ime ASC";
                break;
            default:
                $sortiranje = "naziv ASC, prezime ASC, ime ASC, vrsta_studija_id ASC";
        }
    } else {
        $sortiranje = "naziv ASC, prezime ASC, ime ASC, vrsta_studija_id ASC";
    }
    $upit = "SELECT tema.*, korisnik.ime, korisnik.prezime FROM tema, korisnik WHERE tema.profesor_id=korisnik.id ORDER BY {$sortiranje}";
    $rezultat = izvrsiUpit($upit);

    foreach ($rezultat as $tema) {
        $upit = "SELECT * FROM vrsta_studija WHERE id={$tema['vrsta_studija_id']}";
        $rezultat1 = izvrsiUpit($upit);
        $studij = mysqli_fetch_assoc($rezultat1);

        $upit = "SELECT * FROM status_teme WHERE id={$tema['status_teme_id']}";
        $rezultat1 = izvrsiUpit($upit);
        $status = mysqli_fetch_assoc($rezultat1);

        echo "<tr>";
        echo "<td>{$tema['naziv']}</td>";
        echo "<td>{$studij['naziv']}</td>";
        echo "<td>{$tema['prezime']} {$tema['ime']}</td>";
        echo "<td>{$tema['opis']}</td>";
        echo "<td>".date("d.m.Y", strtotime($tema['datum_kreiranja']))."</td>";
        echo "<td>{$status['naziv']}</td>";

        if ($tema['status_teme_id'] == 1) {
            $upit = "SELECT * FROM rezervacija WHERE tema_id={$tema['id']} AND status_rezervacije_id=3";
            $rezultat1 = izvrsiUpit($upit);

            echo "<td>";
            if (mysqli_num_rows($rezultat1) != 0) {
                foreach ($rezultat1 as $prijava) {
                    $upit = "SELECT * FROM korisnik WHERE id={$prijava['student_id']}";
                    $rezultat2 = izvrsiUpit($upit);
                    $student = mysqli_fetch_assoc($rezultat2);

                    echo "<li><b>Student: </b>{$student['prezime']} {$student['ime']}, ".date("d.m.Y", strtotime($prijava['datum_kreiranja']))."</li>";
                }
            }

            $upit = "SELECT * FROM rezervacija WHERE tema_id={$tema['id']} AND student_id={$_SESSION['korisnik_id']}";
            $rezultat1 = izvrsiUpit($upit);
            if (mysqli_num_rows($rezultat1) == 0) {
                if ($tema['vrsta_studija_id'] == $_SESSION['studij_id']) {
                    $upit = "SELECT * FROM rezervacija WHERE student_id={$_SESSION['korisnik_id']} AND status_rezervacije_id<>2";
                    $rezultat1 = izvrsiUpit($upit);
                    if (mysqli_num_rows($rezultat1) == 0) {
                        echo "<li><a href='student_popis_tema.php?id={$tema['id']}'><button>Rezerviraj</button></a></li>";
                    } else {
                        echo "<li><b>Ne možete rezervirati ovu temu jer ste već ili rezervirali neku ili čekate na potvrdu rezervacije</b></li>";
                    }
                } else {
                    echo "<li><b>Ne možete rezervirati ovu temu jer niste na studiju za koji je tema zadana</b></li>";
                }
            } else {
                $rezervacija = mysqli_fetch_assoc($rezultat1);
                if ($rezervacija['status_rezervacije_id'] == 2) {
                    echo "<li><b>Vaša rezervacija za ovu temu je odbijena</b></li>";
                }
            }

            echo "</td>";
        } else {
            $upit = "SELECT * FROM rezervacija WHERE tema_id={$tema['id']} AND status_rezervacije_id=1";
            $rezultat1 = izvrsiUpit($upit);
            $rezervacija = mysqli_fetch_assoc($rezultat1);

            $upit = "SELECT * FROM korisnik WHERE id={$rezervacija['student_id']}";
            $rezultat1 = izvrsiUpit($upit);
            $student = mysqli_fetch_assoc($rezultat1);

            echo "<td><ul>";
            echo "<li><b>Student: </b>{$student['prezime']} {$student['ime']}</li>";
            echo "<li><b>Datum rezervacije: </b>".date("d.m.Y", strtotime($rezervacija['datum_vrijedi_od']))."</li>";
            echo "<li><b>Rezervacija vrijedi do: </b>".date("d.m.Y", strtotime($rezervacija['datum_vrijedi_do']))."</li>";
            echo "</ul></td>";
        }

        echo "</tr>";
    }


}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Popis tema</title>
    <link href="css/glavniDizajn.css" rel="stylesheet" type="text/css">
    <link rel="icon" type="image/png" href="slika.png">
</head>
<body>
<header>
    <h1>Popis tema</h1>
</header>
<nav>
    <ul>
        <?php prikaziNavigaciju(); ?>
    </ul>
</nav>
<section>
    <form method="post" action="student_popis_tema.php">
        <label>Sortiraj teme prema</label>
        <select name="sortiraj">
            <option value="1">nazivu teme</option>
            <option value="2" <?php if ($_SERVER['REQUEST_METHOD'] == "POST" && $_POST['sortiraj'] == 2) echo 'selected'; ?>>mentoru</option>
            <option value="3" <?php if ($_SERVER['REQUEST_METHOD'] == "POST" && $_POST['sortiraj'] == 3) echo 'selected'; ?>>studiju</option>
        </select><br/>

        <input type="submit" value="Prikaži teme">
    </form>
    <table>
        <thead>
            <th>Naziv teme</th><th>Studij</th><th>Mentor</th><th>Opis teme</th><th>Datum kreiranja</th><th>Status teme</th><th>Rezervacija</th>
        </thead>
        <tbody>
            <?php prikaziPopisTema(); ?>
        </tbody>
    </table>
</section>
</body>
</html>
